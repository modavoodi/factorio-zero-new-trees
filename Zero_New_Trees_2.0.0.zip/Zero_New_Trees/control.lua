-- REMOVES TREES note: initial chunks generated as part of starting area will not be impacted, will only impact new chunks outside of starting area

script.on_event(defines.events.on_chunk_generated, function(e)
    for key, entity in pairs(e.surface.find_entities(e.area)) do
        if entity.type == "tree" then
            entity.destroy()
        end
    end
end)

